
import React from 'react';
import { GraduationCap, Award, Code, Brain } from 'lucide-react';

const About = () => {
  const certifications = [
    { name: 'Google', icon: '🔍', color: 'from-blue-500 to-green-500' },
    { name: 'IBM', icon: '🔷', color: 'from-blue-600 to-blue-800' },
    { name: 'Microsoft Azure', icon: '☁️', color: 'from-blue-400 to-cyan-500' },
    { name: 'AWS', icon: '🧡', color: 'from-orange-500 to-yellow-500' },
    { name: 'CISCO', icon: '🌐', color: 'from-blue-500 to-purple-600' },
    { name: 'IIT Kanpur (C/C++)', icon: '🎓', color: 'from-indigo-500 to-purple-600' }
  ];

  return (
    <section id="about" className="py-24 bg-gradient-to-b from-black to-gray-900 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-20">
          <h2 className="text-5xl md:text-6xl font-bold text-white mb-6 animate-fade-in">
            About Me
          </h2>
          <div className="w-32 h-[2px] bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 mx-auto animate-scale-in"></div>
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-start">
          {/* Left Side - Personal Story */}
          <div className="space-y-8">
            <div className="group bg-gray-800/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-700/50 hover:border-cyan-400/50 transition-all duration-500 hover:transform hover:scale-[1.02] animate-fade-in">
              <div className="flex items-center mb-6">
                <div className="p-3 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-xl mr-4 group-hover:rotate-12 transition-transform duration-300">
                  <Brain className="text-white" size={28} />
                </div>
                <h3 className="text-2xl font-bold text-white">My Journey</h3>
              </div>
              <p className="text-gray-300 leading-relaxed text-lg">
                I'm a passionate software developer with a deep fascination for artificial intelligence and 
                data-driven systems. My journey in technology started with curiosity about how machines 
                can learn and make intelligent decisions, leading me to specialize in AI and machine learning.
              </p>
            </div>

            <div className="group bg-gray-800/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-700/50 hover:border-cyan-400/50 transition-all duration-500 hover:transform hover:scale-[1.02] animate-fade-in delay-200">
              <div className="flex items-center mb-6">
                <div className="p-3 bg-gradient-to-r from-purple-500 to-indigo-600 rounded-xl mr-4 group-hover:rotate-12 transition-transform duration-300">
                  <GraduationCap className="text-white" size={28} />
                </div>
                <h3 className="text-2xl font-bold text-white">Education</h3>
              </div>
              <div className="space-y-4">
                <div className="p-4 bg-gray-700/30 rounded-xl border-l-4 border-cyan-400">
                  <h4 className="text-xl font-semibold text-white mb-2">
                    B.Tech in Computer Science (AI)
                  </h4>
                  <p className="text-cyan-400 font-medium">Greater Noida Institute of Technology</p>
                  <p className="text-gray-400">Expected Graduation: 2026</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Side - Certifications and Skills */}
          <div className="space-y-8">
            <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-700/50 animate-fade-in delay-300">
              <div className="flex items-center mb-8">
                <div className="p-3 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-xl mr-4">
                  <Award className="text-white" size={28} />
                </div>
                <h3 className="text-2xl font-bold text-white">Certifications</h3>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {certifications.map((cert, index) => (
                  <div
                    key={index}
                    className={`group relative bg-gradient-to-br ${cert.color} p-[1px] rounded-xl hover:scale-105 transition-all duration-300 cursor-pointer`}
                    style={{ animationDelay: `${index * 100}ms` }}
                  >
                    <div className="bg-gray-800 rounded-xl p-4 h-full flex flex-col items-center justify-center space-y-2 group-hover:bg-gray-700 transition-colors duration-300">
                      <div className="text-2xl mb-1 group-hover:scale-110 transition-transform duration-300">
                        {cert.icon}
                      </div>
                      <div className="text-sm text-gray-300 font-medium text-center leading-tight">
                        {cert.name}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-700/50 animate-fade-in delay-400">
              <div className="flex items-center mb-8">
                <div className="p-3 bg-gradient-to-r from-green-500 to-teal-500 rounded-xl mr-4">
                  <Code className="text-white" size={28} />
                </div>
                <h3 className="text-2xl font-bold text-white">Expertise Level</h3>
              </div>
              <div className="space-y-6">
                {[
                  { skill: 'Machine Learning', level: 85 },
                  { skill: 'Web Development', level: 90 },
                  { skill: 'Data Science', level: 80 },
                  { skill: 'Problem Solving', level: 95 }
                ].map((item, index) => (
                  <div key={index} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-300 font-medium">{item.skill}</span>
                      <span className="text-cyan-400 font-semibold">{item.level}%</span>
                    </div>
                    <div className="w-full bg-gray-700 rounded-full h-2 overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full transition-all duration-1000 ease-out"
                        style={{ 
                          width: `${item.level}%`,
                          animationDelay: `${index * 200}ms`
                        }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
