import React from 'react';
import { ArrowDown, Sparkles } from 'lucide-react';

const Hero = () => {
  const scrollToAbout = () => {
    const element = document.getElementById('about');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToProjects = () => {
    const element = document.getElementById('projects');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToContact = () => {
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="min-h-screen flex items-center justify-center bg-black relative overflow-hidden pt-20 md:pt-24">
      {/* Subtle Background Animation */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-gray-500/10 rounded-full mix-blend-multiply filter blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-gray-600/10 rounded-full mix-blend-multiply filter blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gray-400/5 rounded-full mix-blend-multiply filter blur-3xl animate-pulse delay-500"></div>
      </div>

      {/* Floating particles */}
      <div className="absolute inset-0">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-gray-400/20 rounded-full animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${2 + Math.random() * 2}s`
            }}
          ></div>
        ))}
      </div>

      <div className="relative z-10 text-center max-w-5xl mx-auto px-4">
        {/* Enhanced Profile Section */}
        <div className="mb-12 relative">
          <div className="relative inline-block">
            <div className="w-40 h-40 md:w-48 md:h-48 mx-auto rounded-full bg-gradient-to-r from-gray-500 via-gray-400 to-gray-600 p-1 shadow-2xl animate-scale-in">
              <div className="w-full h-full rounded-full bg-gray-900 overflow-hidden relative">
                <img 
                  src="https://i.postimg.cc/d3ZpQ1Wk/2201321520003-ABHISHEK-KUMAR-AI.jpg" 
                  alt="Abhishek Kumar"
                  className="w-full h-full object-cover rounded-full"
                />
                <div className="absolute inset-0 bg-gradient-to-br from-gray-400/10 to-gray-500/10 rounded-full"></div>
              </div>
            </div>
            <div className="absolute -top-2 -right-2 text-gray-400 animate-pulse">
              <Sparkles size={20} />
            </div>
            <div className="absolute -bottom-2 -left-2 text-gray-500 animate-pulse delay-500">
              <Sparkles size={16} />
            </div>
          </div>
        </div>

        {/* Enhanced Typography */}
        <div className="space-y-6 mb-12">
          <h1 className="text-6xl md:text-8xl font-bold text-white mb-6 animate-fade-in">
            <span className="bg-gradient-to-r from-gray-300 via-white to-gray-400 bg-clip-text text-transparent">
              Abhishek Kumar
            </span>
          </h1>
          
          <div className="text-2xl md:text-3xl text-gray-300 mb-8 animate-fade-in delay-300">
            <span className="font-light">Software Developer</span>
            <span className="mx-4 text-gray-400">|</span>
            <span className="font-light">AI Enthusiast</span>
            <span className="mx-4 text-gray-400">|</span>
            <span className="font-light">Problem Solver</span>
          </div>

          <p className="text-xl text-gray-400 max-w-3xl mx-auto leading-relaxed animate-fade-in delay-500">
            Passionate software developer specializing in intelligent, data-driven systems. 
            Currently pursuing B.Tech in Computer Science with focus on Artificial Intelligence.
          </p>
        </div>

        {/* Enhanced CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-6 justify-center mb-16 animate-fade-in delay-700">
          <button
            onClick={scrollToProjects}
            className="group px-8 py-4 bg-gradient-to-r from-gray-700 to-gray-600 text-white font-semibold rounded-2xl hover:from-gray-600 hover:to-gray-500 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-gray-500/25 relative overflow-hidden"
          >
            <span className="relative z-10">View Projects</span>
            <div className="absolute inset-0 bg-gradient-to-r from-gray-600 to-gray-500 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          </button>
          
          <button
            onClick={scrollToContact}
            className="px-8 py-4 border-2 border-gray-400 text-gray-300 font-semibold rounded-2xl hover:bg-gray-400 hover:text-gray-900 transition-all duration-300 transform hover:scale-105 backdrop-blur-sm bg-gray-900/20"
          >
            Contact Me
          </button>
          
          <a
            href="#"
            className="px-8 py-4 bg-gray-800/80 backdrop-blur-sm text-white font-semibold rounded-2xl hover:bg-gray-700 transition-all duration-300 transform hover:scale-105 border border-gray-700 hover:border-gray-600"
          >
            Download Resume
          </a>
        </div>

        {/* Enhanced Scroll Indicator */}
        <div className="animate-fade-in delay-1000">
          <button
            onClick={scrollToAbout}
            className="group flex flex-col items-center text-gray-400 hover:text-gray-300 transition-all duration-300"
          >
            <div className="mb-2 text-sm font-medium opacity-75 group-hover:opacity-100">Explore More</div>
            <div className="p-3 rounded-full border border-gray-500/30 group-hover:border-gray-400 transition-all duration-300 animate-bounce">
              <ArrowDown size={24} />
            </div>
          </button>
        </div>
      </div>
    </section>
  );
};

export default Hero;
