
import React, { useState } from 'react';
import { Mail, Phone, Linkedin, Github, Award, Trophy } from 'lucide-react';
import emailjs from '@emailjs/browser';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const result = await emailjs.send(
        'abhieshek11', // service ID
        'template_xq5byie', // template ID
        {
          from_name: formData.name,
          from_email: formData.email,
          message: formData.message,
          to_name: 'Abhishek Kumar',
        },
        'g03leKlhjEWSy9Kqb' // public key
      );

      console.log('Email sent successfully:', result);
      alert('Thank you for your message! I\'ll get back to you soon.');
      setFormData({ name: '', email: '', message: '' });
    } catch (error) {
      console.error('Failed to send email:', error);
      alert('Sorry, there was an error sending your message. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const contactMethods = [
    {
      icon: <Mail className="text-cyan-400" size={24} />,
      label: 'Email',
      value: 'abhieshek11@gmail.com',
      href: 'mailto:abhieshek11@gmail.com',
      gradient: 'from-cyan-500 to-blue-600'
    },
    {
      icon: <Phone className="text-green-400" size={24} />,
      label: 'Phone',
      value: '+91-8130168024',
      href: 'tel:+918130168024',
      gradient: 'from-green-500 to-teal-600'
    },
    {
      icon: <Linkedin className="text-blue-400" size={24} />,
      label: 'LinkedIn',
      value: 'linkedin.com/in/abhieshek11',
      href: 'https://linkedin.com/in/abhieshek11',
      gradient: 'from-blue-500 to-indigo-600'
    },
    {
      icon: <Github className="text-gray-400" size={24} />,
      label: 'GitHub',
      value: 'github.com/abhieshek11',
      href: 'https://github.com/abhieshek11',
      gradient: 'from-gray-500 to-gray-600'
    }
  ];

  const profiles = [
    {
      icon: <Trophy className="text-yellow-400" size={20} />,
      label: 'HackerRank',
      value: 'hackerrank.com/profile/abhieshek11',
      href: 'https://hackerrank.com/profile/abhieshek11'
    },
    {
      icon: <Award className="text-orange-400" size={20} />,
      label: 'Credly',
      value: 'credly.com/users/abhieshek11',
      href: 'https://credly.com/users/abhieshek11'
    }
  ];

  return (
    <section id="contact" className="py-20 bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Let's Connect
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-cyan-400 to-blue-500 mx-auto mb-6"></div>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Ready to discuss your next project or explore collaboration opportunities? 
            I'd love to hear from you!
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Information */}
          <div className="space-y-8">
            <div className="bg-gray-800 rounded-lg p-8 border border-gray-700">
              <h3 className="text-2xl font-bold text-white mb-6">Get In Touch</h3>
              
              <div className="space-y-4">
                {contactMethods.map((method, index) => (
                  <a
                    key={index}
                    href={method.href}
                    target={method.href.startsWith('http') ? '_blank' : undefined}
                    rel={method.href.startsWith('http') ? 'noopener noreferrer' : undefined}
                    className="flex items-center p-4 bg-gray-700 rounded-lg hover:bg-gray-600 transition-all duration-300 group border border-gray-600 hover:border-gray-500"
                  >
                    <div className={`p-3 rounded-lg bg-gradient-to-r ${method.gradient} mr-4`}>
                      {method.icon}
                    </div>
                    <div>
                      <div className="text-white font-semibold">{method.label}</div>
                      <div className="text-gray-300 text-sm group-hover:text-cyan-400 transition-colors duration-300">
                        {method.value}
                      </div>
                    </div>
                  </a>
                ))}
              </div>
            </div>

            {/* Additional Profiles */}
            <div className="bg-gray-800 rounded-lg p-8 border border-gray-700">
              <h3 className="text-xl font-bold text-white mb-6">Professional Profiles</h3>
              
              <div className="space-y-3">
                {profiles.map((profile, index) => (
                  <a
                    key={index}
                    href={profile.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center p-3 bg-gray-700 rounded-lg hover:bg-gray-600 transition-all duration-300 group border border-gray-600 hover:border-gray-500"
                  >
                    {profile.icon}
                    <div className="ml-3">
                      <div className="text-white font-medium text-sm">{profile.label}</div>
                      <div className="text-gray-400 text-xs group-hover:text-cyan-400 transition-colors duration-300">
                        {profile.value}
                      </div>
                    </div>
                  </a>
                ))}
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-gray-800 rounded-lg p-8 border border-gray-700">
            <h3 className="text-2xl font-bold text-white mb-6">Send Message</h3>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-300 mb-2">
                  Your Name
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  disabled={isSubmitting}
                  className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg focus:outline-none focus:border-cyan-400 text-white placeholder-gray-400 transition-colors duration-300 disabled:opacity-50"
                  placeholder="Enter your name"
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-2">
                  Email Address
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  disabled={isSubmitting}
                  className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg focus:outline-none focus:border-cyan-400 text-white placeholder-gray-400 transition-colors duration-300 disabled:opacity-50"
                  placeholder="Enter your email"
                />
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-300 mb-2">
                  Message
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  disabled={isSubmitting}
                  rows={6}
                  className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg focus:outline-none focus:border-cyan-400 text-white placeholder-gray-400 resize-none transition-colors duration-300 disabled:opacity-50"
                  placeholder="Tell me about your project or inquiry..."
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-gradient-to-r from-cyan-500 to-blue-500 text-white py-3 px-6 rounded-lg hover:from-cyan-600 hover:to-blue-600 transition-all duration-300 font-medium transform hover:scale-105 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
              >
                {isSubmitting ? 'Sending...' : 'Send Message'}
              </button>
            </form>

            <div className="mt-8 pt-6 border-t border-gray-700 text-center">
              <p className="text-gray-400 text-sm">
                I typically respond within 24 hours
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
