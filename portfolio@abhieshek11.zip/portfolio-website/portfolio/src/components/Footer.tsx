
import React from 'react';
import { Heart, ArrowUp } from 'lucide-react';

const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-black py-12 border-t border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          {/* Back to Top Button */}
          <button
            onClick={scrollToTop}
            className="inline-flex items-center justify-center w-12 h-12 bg-gradient-to-r from-cyan-500 to-blue-500 text-white rounded-full hover:from-cyan-600 hover:to-blue-600 transition-all duration-300 transform hover:scale-110 shadow-lg mb-8"
          >
            <ArrowUp size={20} />
          </button>

          {/* Footer Content */}
          <div className="space-y-4">
            <h3 className="text-2xl font-bold text-white">Abhishek Kumar</h3>
            <p className="text-gray-400 max-w-md mx-auto">
              Building intelligent solutions that make a difference. 
              Let's create something amazing together.
            </p>
            
            {/* Social Links */}
            <div className="flex justify-center space-x-6 pt-4">
              <a
                href="mailto:abhieshek11@gmail.com"
                className="text-gray-400 hover:text-cyan-400 transition-colors duration-300"
              >
                Email
              </a>
              <a
                href="https://linkedin.com/in/abhieshek11"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-cyan-400 transition-colors duration-300"
              >
                LinkedIn
              </a>
              <a
                href="https://github.com/abhieshek11"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-cyan-400 transition-colors duration-300"
              >
                GitHub
              </a>
            </div>
          </div>

          {/* Copyright */}
          <div className="pt-8 mt-8 border-t border-gray-800">
            <p className="text-gray-500 text-sm flex items-center justify-center">
              © 2024 Abhishek Kumar. Made with 
              <Heart className="text-red-500 mx-1" size={16} />
              and lots of code.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
