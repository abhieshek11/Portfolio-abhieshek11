
import React from 'react';
import { Code, Brain, BarChart3, Zap, Globe, Database } from 'lucide-react';

const Services = () => {
  const services = [
    {
      icon: <Globe className="text-cyan-400" size={40} />,
      title: 'Web Development',
      subtitle: 'Frontend & Backend',
      description: 'Full-stack web applications using modern frameworks like React, Node.js, and Express. Responsive design with optimal performance.',
      features: ['Responsive Design', 'Modern Frameworks', 'API Integration', 'Performance Optimization'],
      gradient: 'from-cyan-500 to-blue-600'
    },
    {
      icon: <Brain className="text-purple-400" size={40} />,
      title: 'AI & ML Prototyping',
      subtitle: 'Intelligent Solutions',
      description: 'Custom AI models and machine learning solutions for various business needs. From computer vision to natural language processing.',
      features: ['Custom ML Models', 'Computer Vision', 'NLP Solutions', 'Model Deployment'],
      gradient: 'from-purple-500 to-pink-600'
    },
    {
      icon: <BarChart3 className="text-green-400" size={40} />,
      title: 'Data Analysis & Visualization',
      subtitle: 'Insights from Data',
      description: 'Transform raw data into actionable insights with advanced analytics and beautiful visualizations using Python and R.',
      features: ['Statistical Analysis', 'Data Visualization', 'Predictive Modeling', 'Report Generation'],
      gradient: 'from-green-500 to-teal-600'
    },
    {
      icon: <Zap className="text-yellow-400" size={40} />,
      title: 'API Integration',
      subtitle: 'Seamless Connections',
      description: 'Integrate third-party services and APIs to enhance functionality. RESTful API development and microservices architecture.',
      features: ['REST API Development', 'Third-party Integration', 'Microservices', 'API Security'],
      gradient: 'from-yellow-500 to-orange-600'
    }
  ];

  return (
    <section id="services" className="py-20 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Services
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-cyan-400 to-blue-500 mx-auto mb-6"></div>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Comprehensive technical solutions tailored to meet your specific needs
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="bg-gray-900 rounded-lg overflow-hidden shadow-xl border border-gray-800 hover:border-gray-700 transition-all duration-300 hover:transform hover:scale-105 group"
            >
              {/* Service Header */}
              <div className={`bg-gradient-to-r ${service.gradient} p-6 relative overflow-hidden`}>
                <div className="absolute top-0 right-0 w-32 h-32 transform translate-x-16 -translate-y-16">
                  <div className="w-full h-full bg-white bg-opacity-10 rounded-full"></div>
                </div>
                <div className="relative z-10 flex items-center">
                  {service.icon}
                  <div className="ml-4">
                    <h3 className="text-2xl font-bold text-white mb-1">
                      {service.title}
                    </h3>
                    <p className="text-white text-opacity-80 text-sm">
                      {service.subtitle}
                    </p>
                  </div>
                </div>
              </div>

              {/* Service Content */}
              <div className="p-6">
                <p className="text-gray-300 mb-6 leading-relaxed">
                  {service.description}
                </p>

                {/* Features List */}
                <div className="space-y-3">
                  <h4 className="text-sm font-semibold text-cyan-400 mb-3">What's Included:</h4>
                  {service.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-center text-gray-300">
                      <div className="w-2 h-2 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full mr-3"></div>
                      <span className="text-sm">{feature}</span>
                    </div>
                  ))}
                </div>

                {/* CTA Button */}
                <div className="mt-6 pt-6 border-t border-gray-800">
                  <button className="w-full bg-gradient-to-r from-gray-700 to-gray-600 text-white py-3 px-4 rounded-lg hover:from-gray-600 hover:to-gray-500 transition-all duration-300 font-medium">
                    Get Started
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Process Section */}
        <div className="mt-16 bg-gray-900 rounded-lg p-8 border border-gray-800">
          <div className="text-center mb-8">
            <h3 className="text-3xl font-bold text-white mb-4">My Process</h3>
            <p className="text-gray-400">How I approach every project</p>
          </div>

          <div className="grid md:grid-cols-4 gap-6">
            {[
              { step: '01', title: 'Discovery', desc: 'Understanding your requirements and goals' },
              { step: '02', title: 'Planning', desc: 'Creating detailed project roadmap' },
              { step: '03', title: 'Development', desc: 'Building with best practices and testing' },
              { step: '04', title: 'Delivery', desc: 'Deployment and ongoing support' }
            ].map((phase, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full flex items-center justify-center mx-auto mb-4 text-white font-bold text-xl">
                  {phase.step}
                </div>
                <h4 className="text-lg font-semibold text-white mb-2">{phase.title}</h4>
                <p className="text-gray-400 text-sm">{phase.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;
