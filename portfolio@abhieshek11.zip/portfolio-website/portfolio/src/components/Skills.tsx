
import React from 'react';
import { Code, Database, Globe, GitBranch, Brain, Users } from 'lucide-react';

const Skills = () => {
  const skillCategories = [
    {
      title: 'Programming Languages',
      icon: <Code className="text-cyan-400" size={24} />,
      skills: ['Python', 'Java', 'C++', 'C', 'R'],
      color: 'from-cyan-400 to-blue-500'
    },
    {
      title: 'Web & App Development',
      icon: <Globe className="text-green-400" size={24} />,
      skills: ['HTML', 'CSS', 'JavaScript', 'Flask', 'Spring Boot', 'React', 'Node.js', 'Express.js'],
      color: 'from-green-400 to-teal-500'
    },
    {
      title: 'Data Science & ML',
      icon: <Brain className="text-purple-400" size={24} />,
      skills: ['Jupyter', 'RStudio', 'pandas', 'NumPy', 'matplotlib', 'ggplot2'],
      color: 'from-purple-400 to-pink-500'
    },
    {
      title: 'Databases',
      icon: <Database className="text-orange-400" size={24} />,
      skills: ['MongoDB', 'MySQL'],
      color: 'from-orange-400 to-red-500'
    },
    {
      title: 'Version Control',
      icon: <GitBranch className="text-yellow-400" size={24} />,
      skills: ['Git', 'GitHub'],
      color: 'from-yellow-400 to-orange-500'
    },
    {
      title: 'Soft Skills',
      icon: <Users className="text-indigo-400" size={24} />,
      skills: ['Problem-solving', 'Communication', 'Time Management', 'Team Collaboration'],
      color: 'from-indigo-400 to-blue-500'
    }
  ];

  return (
    <section id="skills" className="py-20 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Skills & Expertise
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-cyan-400 to-blue-500 mx-auto mb-6"></div>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            A comprehensive toolkit built through continuous learning and hands-on experience
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skillCategories.map((category, index) => (
            <div
              key={index}
              className="bg-gray-900 rounded-lg p-6 shadow-xl border border-gray-800 hover:border-gray-700 transition-all duration-300 hover:transform hover:scale-105"
            >
              <div className="flex items-center mb-4">
                {category.icon}
                <h3 className="text-xl font-bold text-white ml-3">{category.title}</h3>
              </div>
              
              <div className="space-y-3">
                {category.skills.map((skill, skillIndex) => (
                  <div
                    key={skillIndex}
                    className={`inline-block bg-gradient-to-r ${category.color} text-white text-sm px-3 py-1 rounded-full mr-2 mb-2 font-medium shadow-lg`}
                  >
                    {skill}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Interactive Skills Bar */}
        <div className="mt-16 bg-gray-900 rounded-lg p-8 border border-gray-800">
          <h3 className="text-2xl font-bold text-white mb-8 text-center">Proficiency Levels</h3>
          <div className="grid md:grid-cols-2 gap-8">
            {[
              { skill: 'Python', level: 90 },
              { skill: 'Machine Learning', level: 85 },
              { skill: 'Web Development', level: 80 },
              { skill: 'Data Analysis', level: 85 },
              { skill: 'Java', level: 75 },
              { skill: 'React', level: 70 }
            ].map((item, index) => (
              <div key={index} className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-300 font-medium">{item.skill}</span>
                  <span className="text-cyan-400 font-bold">{item.level}%</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-3">
                  <div
                    className="bg-gradient-to-r from-cyan-400 to-blue-500 h-3 rounded-full transition-all duration-1000 ease-out"
                    style={{ width: `${item.level}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;
