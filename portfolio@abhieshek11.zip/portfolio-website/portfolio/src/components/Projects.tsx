
import React from 'react';
import { ExternalLink, Github, Eye, Camera, MessageSquare, User } from 'lucide-react';

const Projects = () => {
  const projects = [
    {
      title: 'Real-Time Face Recognition System',
      description: 'Advanced computer vision system utilizing deep learning algorithms for accurate face detection and recognition in real-time video streams.',
      techStack: ['Python', 'OpenCV', 'TensorFlow', 'NumPy', 'Keras'],
      achievements: ['99.2% accuracy rate', 'Real-time processing', 'Multi-face detection'],
      icon: <Eye className="text-cyan-400" size={32} />,
      gradient: 'from-cyan-500 to-blue-600'
    },
    {
      title: 'Advanced Image Captioning System',
      description: 'AI-powered system that generates natural language descriptions for images using CNN-RNN architecture and attention mechanisms.',
      techStack: ['Python', 'PyTorch', 'NLTK', 'CNN', 'LSTM'],
      achievements: ['BLEU score: 0.78', 'Attention mechanism', 'Multi-language support'],
      icon: <Camera className="text-purple-400" size={32} />,
      gradient: 'from-purple-500 to-pink-600'
    },
    {
      title: 'Personal Portfolio Website',
      description: 'Modern, responsive portfolio website built with React and modern web technologies, featuring smooth animations and optimal performance.',
      techStack: ['React', 'TypeScript', 'Tailwind CSS', 'Vite'],
      achievements: ['100% Lighthouse score', 'Responsive design', 'SEO optimized'],
      icon: <User className="text-green-400" size={32} />,
      gradient: 'from-green-500 to-teal-600'
    }
  ];

  return (
    <section id="projects" className="py-20 bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Featured Projects
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-cyan-400 to-blue-500 mx-auto mb-6"></div>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Showcasing innovative solutions that demonstrate technical expertise and problem-solving abilities
          </p>
        </div>

        <div className="grid lg:grid-cols-3 md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <div
              key={index}
              className="bg-gray-800 rounded-lg overflow-hidden shadow-xl border border-gray-700 hover:border-gray-600 transition-all duration-300 hover:transform hover:scale-105 group"
            >
              {/* Project Header */}
              <div className={`bg-gradient-to-r ${project.gradient} p-6 relative overflow-hidden`}>
                <div className="absolute top-0 right-0 w-20 h-20 transform translate-x-10 -translate-y-10">
                  <div className="w-full h-full bg-white bg-opacity-10 rounded-full"></div>
                </div>
                <div className="relative z-10">
                  {project.icon}
                  <h3 className="text-xl font-bold text-white mt-4 mb-2">
                    {project.title}
                  </h3>
                </div>
              </div>

              {/* Project Content */}
              <div className="p-6">
                <p className="text-gray-300 mb-4 leading-relaxed">
                  {project.description}
                </p>

                {/* Tech Stack */}
                <div className="mb-4">
                  <h4 className="text-sm font-semibold text-cyan-400 mb-2">Tech Stack:</h4>
                  <div className="flex flex-wrap gap-2">
                    {project.techStack.map((tech, techIndex) => (
                      <span
                        key={techIndex}
                        className="bg-gray-700 text-gray-300 px-2 py-1 rounded text-xs font-medium"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Achievements */}
                <div className="mb-6">
                  <h4 className="text-sm font-semibold text-cyan-400 mb-2">Key Achievements:</h4>
                  <ul className="space-y-1">
                    {project.achievements.map((achievement, achIndex) => (
                      <li key={achIndex} className="text-gray-300 text-sm flex items-center">
                        <div className="w-1.5 h-1.5 bg-cyan-400 rounded-full mr-2"></div>
                        {achievement}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3">
                  <button className="flex-1 bg-gradient-to-r from-cyan-500 to-blue-500 text-white py-2 px-4 rounded-lg hover:from-cyan-600 hover:to-blue-600 transition-all duration-300 text-sm font-medium flex items-center justify-center">
                    <ExternalLink size={16} className="mr-2" />
                    View Live
                  </button>
                  <button className="flex-1 bg-gray-700 text-gray-300 py-2 px-4 rounded-lg hover:bg-gray-600 transition-all duration-300 text-sm font-medium flex items-center justify-center">
                    <Github size={16} className="mr-2" />
                    Code
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Additional Projects Teaser */}
        <div className="text-center mt-12">
          <div className="bg-gray-800 rounded-lg p-8 border border-gray-700">
            <MessageSquare className="text-cyan-400 mx-auto mb-4" size={48} />
            <h3 className="text-2xl font-bold text-white mb-4">More Projects Coming Soon</h3>
            <p className="text-gray-400 mb-6">
              I'm constantly working on new and exciting projects. Stay tuned for updates!
            </p>
            <button className="bg-gradient-to-r from-cyan-500 to-blue-500 text-white px-6 py-3 rounded-lg hover:from-cyan-600 hover:to-blue-600 transition-all duration-300 font-medium">
              View All Projects
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Projects;
